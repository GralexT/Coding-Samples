Added workbench query exports if your preference is to import to workbench.
All function/query/view questions are followed up with their relevant call/select statement.
Be sure to keep hydrated!